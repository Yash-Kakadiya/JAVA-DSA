/*
*56. Write a program to implement a node structure for singly linked list. Read the data in a node, print the node.
*
 * 57. Write a menu driven program to implement following operations on the singly 
linked list.  
     Insert a node at the front of the linked list. 
     Display all nodes. 
     Delete a first node of the linked list. 
     Insert a node at the end of the linked list. 
     Delete a last node of the linked list. 
     Delete a node from specified position.
 */

import java.util.Scanner;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class LinkedList {

    // Node blueprint
    public static class Node {
        int data;
        Node next;

        public Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public static Node head;

    public void addFirst(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            return;
        }

        newNode.next = head;
        head = newNode;
    }

    public void addLast(int data) {
        Node newNode = new Node(data);
        Node temp = head;
        if (head == null) {
            head = newNode;
            return;
        }
        while (temp != null) {
            temp = temp.next;
        }
        temp.next = newNode;
        return;
    }

    public void printList() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    public void add(int idx, int data) {
        if (idx == 0) {
            addFirst(data);
            return;
        }
        Node newNode = new Node(data);
        Node temp = head;
        int i = 0;

        while (i < idx - 1) {
            temp = temp.next;
            i++;
        }
        newNode.next = temp.next;
        temp.next = newNode;
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        LinkedList li = new LinkedList();

        while (true) {
            System.out.println("Menu options : ");
            System.out.println("1.Insert a node at the front of the linked list.");
            System.out.println("2.Display all nodes.");
            System.out.println("3.Delete a first node of the linked list.");
            System.out.println("4.Insert a node at the end of the linked list.");
            System.out.println("5.Delete a last node of the linked list. ");
            System.out.println("6.Delete a node from specified position.");
            System.out.println("Enter anything eles to exit...");
            System.out.print("Enter option : ");
            int op = sc.nextInt();

            switch (op) {
                case 1:
                    System.out.print("Enter value to be inserted at first : ");
                    li.addFirst(sc.nextInt());
                    break;
                case 2:
                    System.out.print("Displaying : ");
                    li.printList();
                    break;
                case 3:
                    // li.deleteFirst();
                    break;
                case 4:
                    System.out.print("Enter value to be inserted at last : ");
                    li.addLast(sc.nextInt());
                    break;
                case 5:
                    // li.deleteLast();
                    break;
                case 6:
                    System.out.print("Enter position to be delete : ");
                    // li.deletePos(sc.nextInt());
                    break;
                default:
                    System.out.println("Exiting...");
                    sc.close();
                    return;
            }

        }

    }
}

public class BST {

    public static void main(String[] args) {
        int[] arr={1,2,3,4,5,6,7};

        BinaryTree bt=new BinaryTree();

        bt.root=bt.arrToBTRecursive(arr,0);
        bt.preOrder(bt.root);

        
    }
}
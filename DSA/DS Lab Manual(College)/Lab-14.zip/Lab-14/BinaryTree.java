import java.util.LinkedList;
import java.util.Queue;

class BinaryTree {

        class Node{
            int info;
            Node left;
            Node right;

            public Node(int info){
                this.info=info;
                this.left=null;
                this.right=null;
            }
        }
    public Node root=null;

    void preOrder(Node node){
        if (node==null) {
            
            return;
        }

        System.out.println(node.info+" ");
        preOrder(node.left);
        preOrder(node.right);
    }

    void insertNode(int x){
        Node newNode=new Node(x);
        Queue<Node> queue=new LinkedList<>();
        if(root==null){
            root=newNode;
            return;
        }
        queue.add(newNode);
        
    }

    Node arrToBTRecursive(int[] arr,int idx){
        if (idx>=arr.length) {
            return null;
        }
        Node newNode=new Node(arr[idx]);
        newNode.left=arrToBTRecursive(arr, idx*2+1);
        newNode.right=arrToBTRecursive(arr, idx*2+2);
        return newNode;
    }
}
